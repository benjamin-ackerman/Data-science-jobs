make_call <- function(...) {
  as.call(list(...))
}
