## Test environments
* OS X El Capitan, R 3.4.0
* ubuntu 12.04 (on travis-ci), R 3.4.1, 3.3.3, R-devel
* Windows Server 2012 R2 (x64), R 3.4.1
* Rhub

## R CMD check results
There were no NOTEs, ERRORs or WARNINGs.

## Downstream dependencies
* I ran R CMD check on all 30 downstream dependencies of withr
  Summary at: https://github.com/r-lib/covr/tree/master/revdep
